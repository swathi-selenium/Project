INSERT INTO bank.login (cust_id,emp_id,username,"password",last_login,"type") VALUES
	 (NULL,1,'e1','e1',NULL,'E'),
	 (42,0,'space','space',NULL,'C'),
	 (43,0,'earth','earth',NULL,'C'),
	 (44,0,'water','water',NULL,'C'),
	 (45,0,'fire','fire',NULL,'C'),
	 (46,0,'air','air',NULL,'C'),
	 (47,0,'mango','fruit',NULL,'C'),
	 (48,0,'ganga','river',NULL,'C'),
	 (49,0,'btiger','ranimal',NULL,'C'),
	 (50,0,'peacock','bird',NULL,'C');
INSERT INTO bank.login (cust_id,emp_id,username,"password",last_login,"type") VALUES
	 (51,0,'kcobra','reptile',NULL,'C'),
	 (52,0,'elephant','hanimal',NULL,'C'),
	 (53,0,'lotus','flower',NULL,'C'),
	 (54,0,'pumpkin','vegetable',NULL,'C'),
	 (55,0,'mercury','planet1',NULL,'C'),
	 (56,0,'venus','planet2',NULL,'C'),
	 (57,0,'mars','planet4',NULL,'C'),
	 (58,0,'jupiter','planet5',NULL,'C'),
	 (59,0,'saturn','planet6',NULL,'C'),
	 (60,0,'uranus','planet7',NULL,'C');
INSERT INTO bank.login (cust_id,emp_id,username,"password",last_login,"type") VALUES
	 (61,0,'neptune','planet8',NULL,'C'),
	 (62,0,'pen','pen',NULL,'C');