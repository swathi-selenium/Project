INSERT INTO bank.customer (first_name,last_name,date_of_birth,address,city,zip,state,country,address_proof,ssn,customer_status,phone_number,gender) VALUES
	 ('Space','Space','01-01-2021',NULL,NULL,0,NULL,NULL,NULL,'111-111-1111',NULL,NULL,NULL),
	 ('Earth','Earth','02-02-2021',NULL,NULL,0,NULL,NULL,NULL,'222-222-2222',NULL,NULL,NULL),
	 ('Water','Water','03-03-2021',NULL,NULL,0,NULL,NULL,NULL,'333-333-3333',NULL,NULL,NULL),
	 ('Fire','Fire','04-04-2021',NULL,NULL,0,NULL,NULL,NULL,'444-444-4444',NULL,NULL,NULL),
	 ('Air','Air','05-05-2021',NULL,NULL,0,NULL,NULL,NULL,'555-555-5555',NULL,NULL,NULL),
	 ('Mango','Fruit','06-06-2021',NULL,NULL,0,NULL,NULL,NULL,'666-666-6666',NULL,NULL,NULL),
	 ('Ganga','River','07-07-2021',NULL,NULL,0,NULL,NULL,NULL,'777-777-7777',NULL,NULL,NULL),
	 ('BTiger','RAnimal','08-08-2021',NULL,NULL,0,NULL,NULL,NULL,'888-888-8888',NULL,NULL,NULL),
	 ('Peacock','Bird','09-09-2021',NULL,NULL,0,NULL,NULL,NULL,'999-999-9999',NULL,NULL,NULL),
	 ('KCobra','Reptile','10-10-2021',NULL,NULL,0,NULL,NULL,NULL,'101-101-1010',NULL,NULL,NULL);
INSERT INTO bank.customer (first_name,last_name,date_of_birth,address,city,zip,state,country,address_proof,ssn,customer_status,phone_number,gender) VALUES
	 ('Elephant','HAnimal','11-11-2021',NULL,NULL,0,NULL,NULL,NULL,'111-111-1110',NULL,NULL,NULL),
	 ('Lotus','Flower','12-12-2021',NULL,NULL,0,NULL,NULL,NULL,'121-121-1210',NULL,NULL,NULL),
	 ('Pumpkin','Vegetable','13-01-2021',NULL,NULL,0,NULL,NULL,NULL,'131-131-1310',NULL,NULL,NULL),
	 ('Mercury','Planet1','14-02-2021',NULL,NULL,0,NULL,NULL,NULL,'141-141-1410',NULL,NULL,NULL),
	 ('Venus','Planet2','15-03-2021',NULL,NULL,0,NULL,NULL,NULL,'151-151-1510',NULL,NULL,NULL),
	 ('Mars','Planet4','16-04-2021',NULL,NULL,0,NULL,NULL,NULL,'161-161-1610',NULL,NULL,NULL),
	 ('Jupiter','Planet5','17-05-2021',NULL,NULL,0,NULL,NULL,NULL,'171-171-1710',NULL,NULL,NULL),
	 ('Saturn','Planet6','18-06-2021',NULL,NULL,0,NULL,NULL,NULL,'181-181-1810',NULL,NULL,NULL),
	 ('Uranus','Planet7','19-07-2021',NULL,NULL,0,NULL,NULL,NULL,'191-191-1910',NULL,NULL,NULL),
	 ('Neptune','Planet8','20-08-2021',NULL,NULL,0,NULL,NULL,NULL,'201-201-2010',NULL,NULL,NULL);
INSERT INTO bank.customer (first_name,last_name,date_of_birth,address,city,zip,state,country,address_proof,ssn,customer_status,phone_number,gender) VALUES
	 ('Pen','Pen','24-12-2021',NULL,NULL,0,NULL,NULL,NULL,'205-205-2050',NULL,NULL,NULL);