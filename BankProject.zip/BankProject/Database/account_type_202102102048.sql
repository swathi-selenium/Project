INSERT INTO bank.account_type (acct_type) VALUES
	 ('Checking'),
	 ('Savings  ');