-- bank.transaction_type definition

-- Drop table

-- DROP TABLE bank.transaction_type;

CREATE TABLE bank.transaction_type (
	tran_type_id serial NOT NULL,
	tran_type varchar(100) NULL,
	CONSTRAINT transaction_type_pkey PRIMARY KEY (tran_type_id)
);

-- bank.account_type definition

-- Drop table

-- DROP TABLE bank.account_type;

CREATE TABLE bank.account_type (
	acct_type_id serial NOT NULL,
	acct_type varchar(100) NULL,
	CONSTRAINT account_type_pkey PRIMARY KEY (acct_type_id)
);

-- bank.customer definition

-- Drop table

-- DROP TABLE bank.customer;

CREATE TABLE bank.customer (
	cust_id serial NOT NULL,
	first_name varchar(50) NULL,
	last_name varchar(50) NULL,
	date_of_birth varchar(50) NULL,
	address varchar(30) NULL,
	city varchar(25) NULL,
	zip int4 NULL,
	state varchar(15) NULL,
	country varchar(20) NULL,
	address_proof bool NULL,
	ssn varchar(12) NULL,
	customer_status bool NULL,
	phone_number varchar(20) NULL,
	gender bpchar(10) NULL,
	CONSTRAINT customer_phone_number_key UNIQUE (phone_number),
	CONSTRAINT customer_pkey PRIMARY KEY (cust_id)
);

-- bank.employee definition

-- Drop table

-- DROP TABLE bank.employee;

CREATE TABLE bank.employee (
	emp_id serial NOT NULL,
	first_name varchar(50) NULL,
	last_name varchar(50) NULL,
	emp_status bool NULL,
	CONSTRAINT employee_pkey PRIMARY KEY (emp_id)
);


-- bank.account definition

-- Drop table

-- DROP TABLE bank.account;

CREATE TABLE bank.account (
	acct_no serial NOT NULL,
	curr_bal float8 NULL,
	acc_cust_id int4 NULL,
	acct_type_id int4 NULL,
	account_status bool NULL,
	review_status varchar(10) NULL,
	CONSTRAINT account_pkey PRIMARY KEY (acct_no)
);


-- bank.account foreign keys

ALTER TABLE bank.account ADD CONSTRAINT fk_acc_cust_id FOREIGN KEY (acc_cust_id) REFERENCES bank.customer(cust_id);
ALTER TABLE bank.account ADD CONSTRAINT fk_acct_type_id FOREIGN KEY (acct_type_id) REFERENCES bank.account_type(acct_type_id);




-- bank.login definition

-- Drop table

-- DROP TABLE bank.login;

CREATE TABLE bank.login (
	login_id serial NOT NULL,
	cust_id int4 NULL,
	emp_id int4 NULL,
	username varchar(30) NULL,
	"password" varchar(30) NULL,
	last_login date NULL,
	"type" varchar(1) NOT NULL,
	CONSTRAINT login_pkey PRIMARY KEY (login_id)
);


-- bank.login foreign keys

ALTER TABLE bank.login ADD CONSTRAINT fk_cust_id FOREIGN KEY (cust_id) REFERENCES bank.customer(cust_id);
ALTER TABLE bank.login ADD CONSTRAINT fk_emp_id FOREIGN KEY (emp_id) REFERENCES bank.employee(emp_id);

-- bank."transaction" definition

-- Drop table

-- DROP TABLE bank."transaction";

CREATE TABLE bank."transaction" (
	trans_id serial NOT NULL,
	trans_cust_id int4 NULL,
	trans_acct_no int4 NULL,
	trans_type_id int4 NULL,
	amt_bal float8 NULL,
	trans_to int4 NULL,
	trans_from int4 NULL,
	accept_status bool NULL,
	"comments" varchar(100) NULL,
	linktrans int4 NULL,
	CONSTRAINT transaction_pkey PRIMARY KEY (trans_id)
);


-- bank."transaction" foreign keys

ALTER TABLE bank."transaction" ADD CONSTRAINT fk_tran_type_id FOREIGN KEY (trans_type_id) REFERENCES bank.transaction_type(tran_type_id);
ALTER TABLE bank."transaction" ADD CONSTRAINT fk_trans_cust_id FOREIGN KEY (trans_cust_id) REFERENCES bank.customer(cust_id);


