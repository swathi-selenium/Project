INSERT INTO bank.account (curr_bal,acc_cust_id,acct_type_id,account_status,review_status) VALUES
	 (200.0,43,2,true,'APPROVE'),
	 (300.0,44,1,true,'APPROVE'),
	 (600.0,47,2,true,'APPROVE'),
	 (700.0,48,1,true,'APPROVE'),
	 (800.0,49,2,true,'APPROVE'),
	 (900.0,50,1,true,'APPROVE'),
	 (1000.0,51,2,true,'APPROVE'),
	 (1100.0,52,1,true,'APPROVE'),
	 (1200.0,53,2,true,'APPROVE'),
	 (1300.0,54,1,true,'APPROVE');
INSERT INTO bank.account (curr_bal,acc_cust_id,acct_type_id,account_status,review_status) VALUES
	 (1400.0,55,2,true,'APPROVE'),
	 (1600.0,57,2,true,'APPROVE'),
	 (1700.0,58,1,true,'APPROVE'),
	 (1800.0,59,2,true,'APPROVE'),
	 (1900.0,60,1,true,'APPROVE'),
	 (2000.0,61,2,true,'APPROVE'),
	 (189.0,42,1,true,'APPROVE'),
	 (27.0,44,2,true,''),
	 (50.0,45,1,true,''),
	 (364.0,45,2,true,'APPROVE');
INSERT INTO bank.account (curr_bal,acc_cust_id,acct_type_id,account_status,review_status) VALUES
	 (536.0,46,1,true,'APPROVE'),
	 (1600.0,56,1,true,'APPROVE'),
	 (-100.0,56,2,true,'APPROVE'),
	 (2500.0,62,2,true,'APPROVE');