INSERT INTO bank.employee (first_name,last_name,emp_status) VALUES
	 ('Test','Test',true),
	 ('Emp Sam','Joes',true);