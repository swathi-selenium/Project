INSERT INTO bank.transaction_type (tran_type) VALUES
	 ('Withdrawal'),
	 ('Deposit    ');