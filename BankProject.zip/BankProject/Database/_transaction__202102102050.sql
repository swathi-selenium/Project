INSERT INTO bank."transaction" (trans_cust_id,trans_acct_no,trans_type_id,amt_bal,trans_to,trans_from,accept_status,"comments",linktrans) VALUES
	 (42,31,1,100.0,0,0,true,NULL,0),
	 (43,32,1,200.0,0,0,true,NULL,0),
	 (44,33,1,300.0,0,0,true,NULL,0),
	 (45,34,1,400.0,0,0,true,NULL,0),
	 (46,35,1,500.0,0,0,true,NULL,0),
	 (47,36,1,600.0,0,0,true,NULL,0),
	 (48,37,1,700.0,0,0,true,NULL,0),
	 (49,38,1,800.0,0,0,true,NULL,0),
	 (50,39,1,900.0,0,0,true,NULL,0),
	 (51,40,1,1000.0,0,0,true,NULL,0);
INSERT INTO bank."transaction" (trans_cust_id,trans_acct_no,trans_type_id,amt_bal,trans_to,trans_from,accept_status,"comments",linktrans) VALUES
	 (52,41,1,1100.0,0,0,true,NULL,0),
	 (53,42,1,1200.0,0,0,true,NULL,0),
	 (54,43,1,1300.0,0,0,true,NULL,0),
	 (55,44,1,1400.0,0,0,true,NULL,0),
	 (56,45,1,1500.0,0,0,true,NULL,0),
	 (57,46,1,1600.0,0,0,true,NULL,0),
	 (58,47,1,1700.0,0,0,true,NULL,0),
	 (59,48,1,1800.0,0,0,true,NULL,0),
	 (60,49,1,1900.0,0,0,true,NULL,0),
	 (61,50,1,2000.0,0,0,true,NULL,0);
INSERT INTO bank."transaction" (trans_cust_id,trans_acct_no,trans_type_id,amt_bal,trans_to,trans_from,accept_status,"comments",linktrans) VALUES
	 (42,31,1,100.0,0,0,true,NULL,0),
	 (42,31,2,11.0,0,0,true,NULL,0),
	 (44,51,1,27.0,0,0,true,NULL,0),
	 (45,52,1,50.0,0,0,true,NULL,0),
	 (45,34,2,36.0,35,34,true,NULL,-780513390),
	 (46,35,1,36.0,35,34,true,NULL,-780513390),
	 (62,53,1,2400.0,0,0,true,NULL,0),
	 (56,45,1,100.0,0,0,true,NULL,0),
	 (56,54,1,100.0,0,0,true,NULL,0),
	 (56,54,2,100.0,53,54,true,NULL,1985092565);
INSERT INTO bank."transaction" (trans_cust_id,trans_acct_no,trans_type_id,amt_bal,trans_to,trans_from,accept_status,"comments",linktrans) VALUES
	 (62,53,1,100.0,53,54,true,NULL,1985092565);